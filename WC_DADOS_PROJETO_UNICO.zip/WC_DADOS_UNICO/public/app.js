const state={history:[],signal:null,signalRoundIndex:null,cooldown:0,green:0,red:0,tie:0,minForce:Number(localStorage.getItem('wc_force')||75),lastSignature:''};
const $=id=>document.getElementById(id); $('forceSlider').value=state.minForce; $('forceValue').textContent=state.minForce+'%';
$('forceSlider').addEventListener('input',e=>{state.minForce=Number(e.target.value);localStorage.setItem('wc_force',state.minForce);$('forceValue').textContent=state.minForce+'%';analyze()});
$('reset').onclick=()=>{state.history=[];state.signal=null;state.signalRoundIndex=null;state.cooldown=0;state.green=state.red=state.tie=0;render();analyze()};
let patterns=[];
fetch('/assets/WC_DADOS_Biblioteca_P001_P1300.json').then(r=>r.json()).then(x=>{patterns=x.padroes||[];$('patternCount').textContent=patterns.length+' padrões';analyze()}).catch(()=>{$('patternCount').textContent='biblioteca indisponível'});
function norm(x){if(!x)return null; x=String(x).toUpperCase(); if(['A','AZUL','BLUE','🔵'].includes(x))return'A'; if(['R','VERMELHO','RED','🔴'].includes(x))return'R'; return x.includes('EMP')||x.includes('⚪')?'E':null}
function parseSeq(s){let m=[...String(s).matchAll(/(?:^|[^A-Z])([AR](?:\s*[,/|;-]\s*[AR]){2,})(?:[^A-Z]|$)/gi)];if(m.length){let z=m[m.length-1][1].match(/[AR]/gi);return z?.map(norm)||null} let z=String(s).match(/[AR]/gi);return z&&z.length>=3?z.map(norm):null}
function tail(n){return state.history.slice(-n).map(norm)}
function countRun(arr,ch){let n=0;for(let i=arr.length-1;i>=0&&arr[i]===ch;i--)n++;return n}
function matches(p){const c=p.condicao||p.descricao||''; const w=Number(p.janela)||0; const a=tail(w||Math.min(10,state.history.length)); const noE=a.filter(x=>x==='A'||x==='R'); const target=norm(p.alvo); if(!target||!a.length)return false;
 let seq=parseSeq(c); if(seq&&seq.length>=3){let t=tail(seq.length); if(t.length===seq.length&&t.every((v,i)=>v===seq[i]))return true}
 let m=c.match(/(?:últimas?|ultima).*?(\d+).*?entradas.*?(A|R).*?(?:representa|>=|pelo menos).*?(\d+)%/i); if(m){let n=+m[1],ch=m[2].toUpperCase(),pct=+m[3],x=tail(n).filter(v=>v===ch).length,den=tail(n).filter(v=>v==='A'||v==='R').length;return den>0&&x/den*100>=pct}
 m=c.match(/(?:últimas?|ultima).*?(\d+).*?(?:rodadas|resultados).*?(A|R).*?(?:entre|de).*?(\d+)%/i); if(m){let n=+m[1],ch=m[2].toUpperCase(),lo=+m[3],x=tail(n).filter(v=>v===ch).length,den=tail(n).filter(v=>v==='A'||v==='R').length;return den>0&&x/den*100>=lo}
 m=c.match(/(?:3|4|5|6|7|8|9|10) ou mais ocorrências consecutivas de (A|R)/i); if(m)return countRun(state.history.map(norm),m[1].toUpperCase())>=Number(c.match(/(\d+) ou mais/)[1]);
 m=c.match(/Nas últimas (\d+) rodadas, contar alternâncias consecutivas >= (\d+)/i); if(m){let x=tail(+m[1]);let al=0;for(let i=1;i<x.length;i++)if(x[i]!==x[i-1]&&x[i]!=='E'&&x[i-1]!=='E')al++;return al>=+m[2]}
 m=c.match(/transição (A->R|R->A) ocorreu pelo menos (\d+) vezes/i); if(m){let x=tail(w||10), pair=m[1].split('->'),n=0;for(let i=1;i<x.length;i++)if(x[i-1]===pair[0]&&x[i]===pair[1])n++;return n>=+m[2]}
 m=c.match(/última assinatura de (\d+) resultados é ([AR,]+)/i); if(m){let seq2=m[2].split(',');let x=tail(+m[1]);return x.length===seq2.length&&x.every((v,i)=>v===seq2[i])}
 m=c.match(/densidade de (A|R) fica entre (\d+)%/i); if(m){let x=tail(w),den=x.filter(v=>v==='A'||v==='R').length,hit=x.filter(v=>v===m[1].toUpperCase()).length;return den>0&&hit/den*100>=+m[2]}
 if(/Combinar frequência, sequência, transições e recência/i.test(c)){let ch=target, x=tail(w||10),den=x.filter(v=>v==='A'||v==='R').length;return den>0&&x.filter(v=>v===ch).length/den>=.5}
 return false}
function analyze(){if(state.signal||state.cooldown>0||state.history.length<10){updateNote();return} let found=patterns.filter(matches);if(!found.length){state.lastSignature='';updateNote();return} found.sort((a,b)=>(Number(b.forca_base)||0)-(Number(a.forca_base)||0));let p=found[0], force=Math.min(100,Number(p.forca_base)||0);if(force<state.minForce){state.lastSignature='';updateNote();return} state.signal={target:norm(p.alvo),pattern:p,force};state.signalRoundIndex=state.history.length;state.lastSignature=state.history.slice(-Math.min(12,state.history.length)).join('');render();}
function onNew(arr){
  const incoming=arr.map(norm).filter(Boolean).slice(-120);
  if(!incoming.length)return;

  const chrono=incoming.slice().reverse();
  const current=state.history;
  if(current.join('')===chrono.join(''))return;

  // Find how many genuinely new chronological rounds arrived.
  let newCount=0;
  let merged=chrono;
  if(current.length){
    const max=Math.min(current.length,chrono.length);
    for(let overlap=max;overlap>=1;overlap--){
      const a=current.slice(-overlap);
      const b=chrono.slice(0,overlap);
      if(a.every((v,i)=>v===b[i])){
        newCount=Math.max(0,chrono.length-overlap);
        merged=current.concat(chrono.slice(overlap));
        break;
      }
    }
    if(!newCount && chrono.length>current.length){
      newCount=chrono.length-current.length;
      merged=chrono;
    }
  }

  state.history=merged.slice(-120);

  if(state.signal){
    const signalIndex=state.signalRoundIndex;
    const after=state.history.slice(signalIndex);
    if(after.length>=2){
      const result=norm(after[1]);
      if(result==='E') state.tie++;
      else if(result===state.signal.target) state.green++;
      else if(result==='A'||result==='R') state.red++;
      state.signal=null;
      state.signalRoundIndex=null;
      const postSignalRounds=Math.max(0,after.length-2);
      state.cooldown=Math.max(0,4-postSignalRounds);
    }
  } else if(state.cooldown>0 && newCount>0){
    state.cooldown=Math.max(0,state.cooldown-newCount);
  }

  state.lastSignature=state.history.slice(-60).join('');
  localStorage.setItem('wc_last_len',state.history.length);
  render(); analyze();
}
async function poll(){try{let r=await fetch('/api/live',{cache:'no-store'});let j=await r.json();if(j.ok&&Array.isArray(j.results)){onNew(j.results);$('status').textContent='AO VIVO'}else{$('status').textContent=j.status==='feed_not_exposed'?'FONTE NÃO EXPÔS FEED':'AGUARDANDO FONTE'}}catch(e){$('status').textContent='ERRO DE CONEXÃO'} }
function render(){let h=state.history; $('count').textContent=h.length+' rodadas';$('green').textContent=state.green;$('red').textContent=state.red;$('tie').textContent=state.tie;$('force').textContent=state.signal?state.signal.force+'%':'—';$('pattern').textContent=state.signal?state.signal.pattern.id:'—';$('window').textContent=state.signal?state.signal.pattern.janela:'—';$('signalText').textContent=state.signal?(state.signal.target==='A'?'ENTRE NO 🔵 AZUL':'ENTRE NO 🔴 VERMELHO'):'AGUARDANDO';$('signalMeta').textContent=state.signal?state.signal.pattern.id+' • força '+state.signal.force+'%':'Sem sinal';let box=$('history');box.innerHTML='';h.slice().reverse().slice(0,80).forEach((v,i)=>{let d=document.createElement('div');d.className='ball '+(v==='A'?'a':v==='R'?'r':'e');d.textContent=v==='A'?'A':v==='R'?'V':'E';box.appendChild(d)});updateNote()}
function updateNote(){if(state.history.length<10){$('cooldown').textContent='Aguardando '+(10-state.history.length)+' rodada(s) para iniciar.'}else if(state.cooldown>0){$('cooldown').textContent='Aguardando '+state.cooldown+' rodada(s) após o sinal.'}else if(!state.signal){$('cooldown').textContent='Sem sinal no momento. Reanalisando a cada nova rodada.'}}
render();poll();setInterval(poll,15000);
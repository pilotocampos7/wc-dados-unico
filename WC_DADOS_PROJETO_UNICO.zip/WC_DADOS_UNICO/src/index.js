import puppeteer from "@cloudflare/puppeteer";

const SOURCE = "https://www.casino.org/casinoscores/pt-br/bac-bo/";
const CACHE_KEY = "https://wc-dados.internal/live";
const CACHE_TTL = 20;

const cors = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET, OPTIONS",
  "access-control-allow-headers": "content-type",
};

const json = (data, status = 200, extra = {}) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { ...cors, "content-type": "application/json; charset=UTF-8", ...extra },
  });

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });

    if (url.pathname === "/api/live") {
      if (!env.MYBROWSER) {
        return json({
          ok: false,
          status: "browser_binding_missing",
          message: "O Browser Run não está ligado ao Worker. Configure o binding MYBROWSER.",
        }, 500);
      }

      const cache = caches.default;
      const cacheRequest = new Request(CACHE_KEY);
      const cached = await cache.match(cacheRequest);
      if (cached) return cached;

      let browser;
      try {
        browser = await puppeteer.launch(env.MYBROWSER, {
          guardrails: { allowedDomains: ["casino.org", "www.casino.org", "*.casino.org"] },
        });

        const page = await browser.newPage();
        await page.setViewport({ width: 1280, height: 1800 });
        await page.goto(SOURCE, { waitUntil: "networkidle2", timeout: 30000 });
        await new Promise((resolve) => setTimeout(resolve, 3500));

        const results = await page.evaluate(() => {
          const map = (value) => {
            const s = String(value || "").trim().toUpperCase();
            if (["A", "AZUL", "BLUE", "PLAYER", "JOGADOR", "🔵"].includes(s)) return "A";
            if (["R", "VERMELHO", "RED", "BANKER", "BANQUEIRO", "🔴"].includes(s)) return "R";
            if (["E", "EMPATE", "TIE", "DRAW", "⚪", "⚪️"].includes(s)) return "E";
            return null;
          };

          const headings = [...document.querySelectorAll("*")].filter((el) =>
            /^(latest rolls|últimas tiradas|últimos tiros|últimas versões)$/i.test((el.textContent || "").trim())
          );

          let scope = document.body;
          if (headings.length) {
            let h = headings[0];
            for (let i = 0; i < 7 && h?.parentElement; i++) {
              const parent = h.parentElement;
              const count = [...parent.querySelectorAll("[aria-label], [title], [alt]")].filter((el) =>
                [el.getAttribute("aria-label"), el.getAttribute("title"), el.getAttribute("alt")].some((v) => map(v))
              ).length;
              if (count >= 10) { scope = parent; break; }
              h = parent;
            }
          }

          const candidates = [...scope.querySelectorAll("[aria-label], [title], [alt]")];
          const out = [];
          const seen = new Set();

          for (const el of candidates) {
            const values = [el.getAttribute("aria-label"), el.getAttribute("title"), el.getAttribute("alt")];
            let hit = null;
            for (const v of values) {
              hit = map(v);
              if (hit) break;
            }
            if (!hit) continue;

            // Deduplicate the same DOM element only; do not remove legitimate A-A/R-R sequences.
            const key = `${el.outerHTML.slice(0, 300)}|${hit}`;
            if (seen.has(key)) continue;
            seen.add(key);
            out.push(hit);
          }

          return out.slice(-120);
        });

        const body = JSON.stringify({
          ok: results.length >= 10,
          source: SOURCE,
          results,
          quantidade: results.length,
          status: results.length >= 10 ? "live" : "insufficient",
          atualizado_em: new Date().toISOString(),
        });

        const response = new Response(body, {
          headers: {
            ...cors,
            "content-type": "application/json; charset=UTF-8",
            "cache-control": `public, max-age=${CACHE_TTL}`,
          },
        });
        ctx.waitUntil(cache.put(cacheRequest, response.clone()));
        return response;
      } catch (error) {
        return json({ ok: false, source: SOURCE, status: "browser_error", message: String(error?.message || error) }, 502);
      } finally {
        try { if (browser) await browser.close(); } catch {}
      }
    }

    // Everything else is the WC DADOS website.
    return env.ASSETS.fetch(request);
  },
};

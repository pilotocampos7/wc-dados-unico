# WC DADOS — Projeto Único

Projeto único para Cloudflare Worker com Static Assets.

Inclui interface, biblioteca P001–P1300 e captura automática via Browser Run.

Regras principais: primeiro sinal após 10 rodadas; sinal azul/vermelho; avaliação da rodada seguinte como GREEN/RED/EMPATE; espera de 4 rodadas após sinal; força mínima padrão 75%.

Binding obrigatório: Browser Run com nome MYBROWSER.

O ZIP contém o projeto completo. Para publicar o código do Worker, use importação por repositório/Wrangler; não trate este ZIP como simples upload de arquivos estáticos.
